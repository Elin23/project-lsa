import { ctaData as defaultCtaData } from "../../../data/ctaData";
import ButtonComponent from "../../shared/ButtonComponent";

export interface CTASectionProps {
  label?: string;
  title?: string;
  description?: string;
  buttonText?: string;
  buttonLink?: string;
}

/**
 * CTASection Component
 * Call to action section with animated background elements and responsive button navigation.
 */
const CTASection = ({
  label = defaultCtaData.label,
  title = defaultCtaData.title,
  description = defaultCtaData.description,
  buttonText = defaultCtaData.buttonText,
  buttonLink = defaultCtaData.buttonLink,
}: CTASectionProps) => {
  return (
    <section
      aria-labelledby="cta-section-title"
      className="pb-16 md:pb-24 2xl:pb-28"
      data-aos="fade-up"
      data-aos-duration="650"
      data-aos-easing="ease-out-cubic"
      data-aos-offset="80"
      data-aos-once="true"
    >
      <div className="group relative overflow-hidden rounded-xl bg-blue-03 px-6 py-12 text-center shadow-lg transition-all duration-700 hover:-translate-y-0.5 hover:shadow-[0_28px_60px_rgba(10,33,90,0.22)] md:px-12 2xl:py-14">
        {/* Background Lines & Animated Decorative Graphics */}
        <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
          {/* Vertical Pipelines */}
          <div className="absolute left-[34%] top-0 h-[85%] w-2.5 bg-white/10 transition-colors duration-700 group-hover:bg-white/13" />
          <div className="absolute left-[45%] top-0 h-[65%] w-2.5 bg-white/10 transition-colors duration-700 group-hover:bg-white/13" />
          <div className="absolute left-[56%] top-0 h-[45%] w-2.5 bg-white/10 transition-colors duration-700 group-hover:bg-white/13" />

          {/* Horizontal Dashed Lines */}
          <div className="absolute left-1/2 top-[20%] w-[320px] -translate-x-1/2 border-t border-dashed border-white/15 transition-colors duration-700 group-hover:border-white/25" />
          <div className="absolute left-1/2 top-[50%] w-[320px] -translate-x-1/2 border-t border-dashed border-white/15 transition-colors duration-700 group-hover:border-white/25" />
          <div className="absolute left-1/2 top-[90%] w-[320px] -translate-x-1/2 border-t border-dashed border-white/15 transition-colors duration-700 group-hover:border-white/25" />

          {/* Main Circles */}
          <div className="absolute bottom-[11%] left-[33.3%] h-8 w-8 animate-pulse rounded-full bg-white/30 transition-all duration-700 group-hover:scale-110 group-hover:bg-white/40" />
          <div className="absolute bottom-[33%] left-[43.9%] h-8 w-8 animate-pulse rounded-full bg-white/30 transition-all duration-700 group-hover:scale-110 group-hover:bg-white/40 [animation-delay:700ms]" />
          <div className="absolute bottom-[54%] left-[55.2%] h-8 w-8 animate-pulse rounded-full bg-white/30 transition-all duration-700 group-hover:scale-110 group-hover:bg-white/40 [animation-delay:1400ms]" />

          {/* Horizontal Connectors */}
          <div className="absolute bottom-[13%] left-[calc(32.3%+22px)] h-2.5 w-90 bg-white/10 transition-colors duration-700 group-hover:bg-white/13" />
          <div className="absolute bottom-[35%] left-[calc(43.2%+22px)] h-2.5 w-90 bg-white/10 transition-colors duration-700 group-hover:bg-white/13" />
          <div className="absolute bottom-[55%] left-[calc(55%+22px)] h-2.5 w-90 bg-white/10 transition-colors duration-700 group-hover:bg-white/13" />
        </div>

        {/* Content Box */}
        <div className="relative z-10 mx-auto flex max-w-180 flex-col items-center gap-4 md:gap-5">
          {label && (
            <span className="text-xs font-bold uppercase tracking-[0.18em] text-white">
              {label}
            </span>
          )}

          <h2
            id="cta-section-title"
            className="max-w-162.5 text-[28px] font-bold leading-9.5 text-white transition-transform duration-700 group-hover:-translate-y-0.5 md:text-[38px] md:leading-11.5 2xl:text-[46px] 2xl:leading-14.5"
          >
            {title}
          </h2>

          {description && (
            <p className="max-w-155 leading-7 text-white/80 transition-colors duration-700 group-hover:text-white md:text-lg 2xl:text-[20px]">
              {description}
            </p>
          )}

          {buttonText && buttonLink && (
            <div className="transition-transform duration-700 group-hover:-translate-y-1">
              <ButtonComponent to={buttonLink}>{buttonText}</ButtonComponent>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default CTASection;